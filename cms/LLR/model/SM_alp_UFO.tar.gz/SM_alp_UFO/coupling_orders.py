# This file was automatically created by FeynRules 2.3.26
# Mathematica version: 11.1.0 for Linux x86 (64-bit) (March 13, 2017)
# Date: Wed 23 Aug 2017 15:59:54


from object_library import all_orders, CouplingOrder


QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

HIW = CouplingOrder(name = 'HIW',
                    expansion_order = 99,
                    hierarchy = 1)

HIG = CouplingOrder(name = 'HIG',
                    expansion_order = 99,
                    hierarchy = 1)

NGB = CouplingOrder(name = 'NGB',
                    expansion_order = 99,
                    hierarchy = 1)

Cbb = CouplingOrder(name = 'Cbb',
                    expansion_order = 99,
                    hierarchy = 1)

Ctt = CouplingOrder(name = 'Ctt',
                    expansion_order = 99,
                    hierarchy = 1)

CK = CouplingOrder(name = 'CK',
                   expansion_order = 99,
                   hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

Cll = CouplingOrder(name = 'Cll',
                    expansion_order = 99,
                    hierarchy = 1)

